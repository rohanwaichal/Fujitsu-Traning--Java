package Project1;
import java.util.Scanner;

public class StudentTest {
	
	 static Student[] student1 = new Student[10];
	 static int count;

	
	static void view(){
		for(Student a: student1){
			System.out.println(a);
		}
	}
	
	static void add(Student student){
		student1[count]= student;
		count++;
	}
	static Student getData() {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the student Details : ID, Name, Marks of(English), Marks of(Maths), Marks of(Science)");
		int id=scan.nextInt();
		String name=scan.next();
		int marks1=scan.nextInt();
		int marks2=scan.nextInt();
		int marks3=scan.nextInt();
		int t=calculateTotal(marks1, marks2, marks3);
		float per=calculatePercentage(t);
		String gra=grade(per);
		Student student = new Student(id, name, marks1, marks2, marks3, t, per, gra);
		return student;
	}
	static int calculateTotal(int m1, int m2, int m3){
		return m1+m2+m3;
	}
	static float calculatePercentage(int t){
		return t/3;
	}
	static String grade(float per) {
		String g=null;
		if(per>=90 && per<100)
			g="Grade A";
		else	if(per>=60 && per<90)
			g="Grade B";
		else if(per>50 && per<60)
			g="Grade c";
		else
			g="failed";
		
		return g;

	}
	
	
	public static void main(String[] args) {
		while(true){
		System.out.println("***********  Menu *********** ");
		System.out.println("1. ADD STUDENT RECORD \n2. VIEW BY ID\n3. VIEW ALL\n4. EXIT\n Enter your choice :");
		Scanner s= new Scanner(System.in);
		int ch=s.nextInt();
		switch(ch){
		case 1:
			add(getData());
			
			break;
		case 2:
			System.out.println("Enter the ID :");
			int id=s.nextInt();
			for(int i=0;i<=2;i++){
				if(student1[i].getStudentId()==id){
					System.out.println(student1[i].getStudentName());
					
					System.out.println("record found");
					break;
				}
				else
					System.out.println("record not found");
			}
			break;
		case 3:
			view();
			break;
		case 4:
			break;	
		}
		}
		
		
	
	}

}
