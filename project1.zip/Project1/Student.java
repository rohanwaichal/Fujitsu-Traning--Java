package Project1;

public class Student {

	private int studentId;
	private String StudentName;
	private int marks1;
	private int marks2;
	private int marks3;
	private int total;
	private float percentage;
	private String grade;

	public Student(int studentId,String studentName,int marks1,int marks2,int marks3, int to, float perc, String gr) {
		super();
		this.studentId = studentId;
		this.StudentName = studentName;
		this.marks1 = marks1;
		this.marks2 = marks2;
		this.marks3 = marks3;
		this.total=to;
		this.percentage=perc;
		this.grade=gr;

	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public float getPercentage() {
		return percentage;
	}

	public void setPercentage(float percentage) {
		this.percentage = percentage;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getStudentId() {
		return studentId;
	}

	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}

	public String getStudentName() {
		return StudentName;
	}

	public void setStudentName(String studentName) {
		StudentName = studentName;
	}

	public int getMaths1() {
		return marks1;
	}

	public void setMaths1(int marks1) {
		this.marks1 = marks1;
	}

	public int getMaths2() {
		return marks2;
	}

	public void setMaths2(int marks2) {
		this.marks2 = marks2;
	}

	public int getMaths3() {
		return marks3;
	}

	public void setMaths3(int marks3) {
		this.marks3 = marks3;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", StudentName=" + StudentName + ", marks1=" + marks1 + ", marks2="
				+ marks2 + ", marks3=" + marks3 + ", total=" + total + ", percentage=" + percentage + ", grade=" + grade
				+ "]";
	
		
		
//	public void show(int id)
//	{
//		System.out.println(student[id].);		
//		
//	}
//	}

	}}
