package music.wind;
import music.*;
import music.string.Veena;


public class Test {

	public static void main(String[] args) {
		Veena veena = new Veena();
		Saxophone saxophone = new Saxophone();
		veena.play();
		saxophone.play();
		
	}

}
