package ProjectOnCollection2;

import java.util.ArrayList;
import java.util.Scanner;

public class employeeInfoTest {
	static ArrayList<EmployeeInfo>	EmployeeList=new ArrayList();
	
	
	public static void main(String[] args) {
		while(true)
		{
			Scanner scanner=new Scanner(System.in);
			System.out.println("***********MENU***********");
			System.out.println(" 1.AddRecord \n 2.DeleteRecord \n 3.FindRecord \n 4.DisplayRecord \n 5.UpdateRecord\n 6.Exit \n Enter your choice:");
			int ch=scanner.nextInt();
			switch(ch){
			case 1:EmployeeInfo.addEmployee();break;
			case 2:EmployeeInfo.deleteRecord();break;
			case 3:EmployeeInfo.findById();break;
			case 4:EmployeeInfo.findAll();break;
			case 5:EmployeeInfo.updateRecord();break;
			case 6:break;
			default:System.out.println("Invalid input");
			}
			
			
			
		}
	
	}

}
