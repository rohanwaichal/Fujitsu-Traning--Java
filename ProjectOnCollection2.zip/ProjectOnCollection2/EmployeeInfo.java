package ProjectOnCollection2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class EmployeeInfo {
	private String empName;
	private String empId;
	private String designation;
	private float grossSalary;
	private float pf;
	private float ctc;
	static ArrayList<EmployeeInfo>	EmployeeList=new ArrayList();

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	

	public EmployeeInfo(String empName, String empId, String designation, float grossSalary, float pf, float ctc) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.designation = designation;
		this.grossSalary = grossSalary;
		this.pf = pf;
		this.ctc = ctc;
	}

	public String getEmpId() {
		return empId;
	}

	public void setEmpId(String empId) {
		this.empId = empId;
	}

	public String getDesignation() {
		return designation;
	}

	public void setDesignation(String designation) {
		this.designation = designation;
	}

	public float getGrossSalary() {
		return grossSalary;
	}

	public void setGrossSalary(float grossSalary) {
		this.grossSalary = grossSalary;
	}

	public float getPf() {
		return pf;
	}

	public void setPf(float pf) {
		this.pf = pf;
	}

	public float getCtc() {
		return ctc;
	}

	public void setCtc(float ctc) {
		this.ctc = ctc;
	}

	public static void addEmployee() {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the employee name,id,designation,ctc");
		String name = sc.next();
		String id = sc.next();
		String designation = sc.next();
		float ctc = sc.nextFloat();
		float basicSalary = calculateGross(ctc);
		float pf = calculatePf(ctc);
		EmployeeInfo employeeInfo = new EmployeeInfo(name,id,designation,ctc,basicSalary,pf);
		EmployeeList.add(employeeInfo);
 
	}
	static void findAll()
	{
		for(EmployeeInfo e:EmployeeList)
		{
			System.out.println(e);
		}
		
		
	}

	static float calculateGross(float ctc) {
        float num=(ctc/100)*40;
        float num1=calculatePf(ctc);
		return num+num1;
	}

	static float calculatePf(float ctc) {
		float num=(ctc/100)*20;
		return num;
	}

	 static void deleteRecord()
	{
		 System.out.println("Enter the id to be deleted :");
		 Scanner sc=new Scanner(System.in);
		 String id=sc.next();
		Iterator<EmployeeInfo>it=EmployeeList.iterator();
		while(it.hasNext())
		{
			EmployeeInfo e=(EmployeeInfo)it.next();
			if(e.getEmpId().equals(id))
			{
				it.remove();
				
			}
				
			break;
			
		}
		
		System.out.println("Record deleted successfully");
	}
	 static void updateRecord()
		{
		 System.out.println("Enter the id to be updated:");
		 Scanner sc=new Scanner(System.in);
		 String id=sc.next();
		 System.out.println("Enter the newname:");
		 String newName=sc.next();
		 Iterator<EmployeeInfo>it=EmployeeList.iterator();
			while(it.hasNext())
			{
				EmployeeInfo e=(EmployeeInfo)it.next();
			if(e.getEmpId().equals(id))
			{
				e.setEmpName(newName);
			}
		}
			System.out.println("Record updated successfully");
		}
	 static void findById()
	 {
		 System.out.println("Enter the Id to be found:");
		 Scanner sc=new Scanner(System.in);
		 String id=sc.next();
		 Iterator<EmployeeInfo>it=EmployeeList.iterator();
			while(it.hasNext())
			{
				EmployeeInfo e=(EmployeeInfo)it.next();
			if(e.getEmpId().equals(id))
			{
				e.toString();
			}
		}
			System.out.println("Record found successfully");
		}
	 
	@Override
	public String toString() {
		return "EmployeeInfo [empName=" + empName + ", empId=" + empId + ", designation=" + designation
				+ ", grossSalary=" + grossSalary + ", pf=" + pf + ", ctc=" + ctc + "]";
	}

}
