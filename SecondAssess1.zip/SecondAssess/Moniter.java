package SecondAssess;

public interface Moniter {
	
	public int getMonQuantity(int count);
	public void getMonPrice();
}
