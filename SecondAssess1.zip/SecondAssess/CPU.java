package SecondAssess;

public interface CPU {
	
	
	public int getCpuQuantity(int count);
	public void getCpuPrice();
    
}
