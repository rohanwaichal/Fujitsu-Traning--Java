package SecondAssess;

public interface Keyboard {
	
	
	public int getKeyQuantity(int count);
	public void getKeyPrice();
}
