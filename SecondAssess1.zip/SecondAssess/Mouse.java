package SecondAssess;

public interface Mouse {
	
	public int getMouQuantity(int count);
	public void getMouPrice();
}
