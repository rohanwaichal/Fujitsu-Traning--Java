package SecondAssess;

import java.util.Scanner;

public class ComputerShop implements CPU, Keyboard, Mouse, Moniter {
	
	static int CpuCount = 20;
	static int KeyCount = 20;
	static int MouCount = 20;
	static int MonCount = 20;
	static double FinalIncome=0;
	Scanner sc = new Scanner(System.in);

	public int getCpuQuantity(int count) {
		CpuCount = CpuCount - count;

		return CpuCount;
	}

	public void getCpuPrice() {
		ComputerShop cs = new ComputerShop();
		System.out.println("1CPU=1000rs");
		System.out.println("Available Stock:"+CpuCount);
		System.out.println("Enter the Number of Cpu u want to purchase:");
		int count = sc.nextInt();
		if(count>CpuCount)
				System.out.println("Unavailable stocks");
		else
		{
		cs.getCpuQuantity(count);
		int price = count * 1000;
		cs.Gross(price);
		System.out.println("Total CPU price:" + price);
		}
	}

	public int getKeyQuantity(int count) {
		KeyCount = KeyCount - count;
		return KeyCount;
	}

	public void getKeyPrice() {
		ComputerShop cs = new ComputerShop();
		System.out.println("1Keyboard=600rs");
		System.out.println("Available Stock:"+KeyCount);
		System.out.println("Enter the Number of Keyboard u want to purchase:");
		int count = sc.nextInt();
		if(count>KeyCount)
			System.out.println("Unavailabe stocks...");
		else
		{
		int price = count * 600;
		cs.getKeyQuantity(count);
		cs.Gross(price);
		System.out.println("Total Keyboard price:" + price);
	  }
	}

	public int getMouQuantity(int count) {
		MouCount = MouCount - count;
		return MouCount;
	}

	public void getMouPrice() {
		ComputerShop cs = new ComputerShop();
		System.out.println("1Mouse=300rs");
		System.out.println("Available Stock:"+MouCount);
		System.out.println("Enter the Number of Mouse u want to purchase:");
		int count = sc.nextInt();
		int price = count * 300;
		cs.getKeyQuantity(count);
		cs.Gross(price);
		System.out.println("Total Mouse price:" + price);
	}

	public int getMonQuantity(int count) {
		MonCount = MonCount - count;
		return MonCount;
	}

	public void getMonPrice() {
		ComputerShop cs = new ComputerShop();
		System.out.println("1Moniter=1200rs");
		System.out.println("Available Stock:"+MonCount);
		System.out.println("Enter the Number of Moniter u want to purchase:");
		int count = sc.nextInt();
		int price = count * 1200;
		cs.getKeyQuantity(count);
		cs.Gross(price);
		System.out.println("Total Moniter price:" + price);
	}

	void purchase() {
		int ch1;
		ComputerShop cs = new ComputerShop();
		do {
			System.out.println("****************Available Items****************");
			System.out.println("\n1.CPU\n2.Mouse\n3.Keyboard\n4.Monitor\n5.Exit\nEnter ur choice:");
			ch1 = sc.nextInt();
			switch (ch1) {
			case 1:
				cs.getCpuPrice();
				break;
			case 2:
				cs.getMouPrice();
				break;
			case 3:
				cs.getKeyPrice();
				break;
			case 4:
				cs.getMonPrice();
				break;
			case 5:
				break;
			default:
				System.out.println("inavalid choice...");
			}
		}while(ch1!=5);
		
	}

	void AddItem() {
		System.out.println("What do u want to add:");
		System.out.println("\n1.CPU\n 2.Mouse\n3.Keyboard\n4.Monitor\n5.Exit\nEnter ur choice:");
		int ch = sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("how many CPU u want to add:");
			int quan = sc.nextInt();
			CpuCount = CpuCount + quan;
			break;
		case 2:
			System.out.println("how many Mouse u want to add:");
			int quan1 = sc.nextInt();
			MouCount = MouCount + quan1;
			break;
		case 3:
			System.out.println("how many Keyboard u want to add:");
			int quan3 = sc.nextInt();
			KeyCount = KeyCount + quan3;
			break;
		case 4:
			System.out.println("how many Moniter u want to add:");
			int quan4 = sc.nextInt();
			MonCount = MonCount + quan4;
			break;
		case 5:System.exit(0);

		}

	}
	double Gross(int amt)
	{
		double gross=(0.25)*amt;
		FinalIncome=FinalIncome+gross;
		return gross;
	
		
	}
	public static void main(String[] args) {
    ComputerShop cs1 = new ComputerShop();	
    int ch;
	Scanner sc = new Scanner(System.in);
	do{	
	System.out.println("******************************  WELCOME TO DELUX COMPUTER SHOP  ************************************* ");
	System.out.println("1.Purchase Item\n2.Add Item\n3.GrossIncome\n4.Exit\nEnter your choice:");
	ch=sc.nextInt();
	switch(ch)
   {
	
	case 1:cs1.purchase();break;
	case 2:cs1.AddItem();break;
	case 3:System.out.println("Final Income is:"+FinalIncome);break;
	case 4: System.exit(0);
	default: System.out.println("Invalid Input..");
	}
	}while(ch!=4);
	}
	

}
