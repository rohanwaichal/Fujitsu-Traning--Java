package Collection;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeCollection {
	static TreeSet<String> ts = new TreeSet<>();
	public static void main(String[] args) {
	
		ts.add("Rohan/Sam");
		ts.add("Bhagyashri/Diksha");
		ts.add("Chino/Ashok");
		Iterator i=ts.descendingIterator();
		while(i.hasNext()){
			String n=(String)i.next();
				System.out.println(n);
			}
				
		}
	}
	


