package Collection;

import java.util.ArrayList;

public class StringCollection {
	static ArrayList<String> al=new ArrayList<>();
	static void printAll()
	{
		for(String s:al)
		{
			System.out.println(s);
		}
		
	}
	
  public static void main(String[] args) {
	 
		al.add("Bhagyashri/Diksha");
		al.add("Rohan/Samrtha");
		al.add("Kanchan/Sakshi");
		al.add("Yash/Ashok");
		System.out.println(al);
		printAll();
}

}
