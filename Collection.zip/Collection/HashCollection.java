package Collection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;

public class HashCollection {
	
	static HashMap<Integer, String> hm = new HashMap<>();
	public static void main(String[] args) {
		
		hm.put(1, "Sam");
		hm.put(2, "Diksha");
		hm.put(3, "Moti");
		hm.put(4, "Langur");
		Iterator<Integer> key= hm.keySet().iterator();
	
		while(key.hasNext()){
			Integer i=(Integer)key.next();
			//System.out.println(i);
			System.out.println(i+"\t"+hm.get(i));
		}
		//getKey();
		getValue();
	}

	static void getKey(){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the key want to search :");
		int a=sc.nextInt();
		Iterator<Integer> key= hm.keySet().iterator();
		while(key.hasNext()){
			Integer i=(Integer)key.next();
			if(i==a){
				System.out.println("Key Found...");
				System.out.println(i+"\t"+hm.get(i));
				
			}
			
		}
	}
	static void getValue(){
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter the value want to search :");
		String a=sc.next();
		Iterator<Integer> val= hm.keySet().iterator();
		while(val.hasNext()){
			Integer i=(Integer)val.next();
			String s=(String)hm.get(i);
			if(a.equals(s)){
				System.out.println("Record Found...");
				System.out.println(i+"\t"+s);
				break;
			}
			else{
				System.out.println("Record Not Found...");
			}
			
		}
	}

}
