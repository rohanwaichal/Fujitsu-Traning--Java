package Collection;
import java.util.ArrayList;
import java.util.Scanner;
public class NumbersCollection {
static ArrayList<Number> al = new ArrayList<>();
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	al.add(34);
	al.add(12.5);
	al.add(89.0f);
	al.add(45.0d);
	
	System.out.println(al);
	
	
}
}
