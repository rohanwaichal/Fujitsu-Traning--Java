package Exercies4;

public class Animal {
	private String name;
	private String nature;
	
	private String color;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNature() {
		return nature;
	}
	public void setNature(String nature) {
		this.nature = nature;
	}
	
	@Override
	public String toString() {
		return "Animal [name=" + name + ", nature=" + nature + ", color=" + color + "]";
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}

}
