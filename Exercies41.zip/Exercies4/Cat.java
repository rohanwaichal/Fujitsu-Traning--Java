package Exercies4;

public class Cat extends Animal{
	void shout() {
		String shoutType = "MEWO-MEOW..!!!";
		System.out.println(shoutType);
	}
}
