package Exercies4;

public class Dog extends Animal {
	public void shout() {
		String shoutType = "BHOU-BHOU..!!!";
		System.out.println(shoutType);
	}
}
