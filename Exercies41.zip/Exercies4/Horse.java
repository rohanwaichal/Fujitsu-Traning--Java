package Exercies4;

public class Horse extends Animal{
	void shout() {
		String shoutType = "SHARUK-KHAN...!!!";
		System.out.println(shoutType);
	}
}
