package Exercies4;

public class AnimalTest {

	public static void main(String[] args) {
		Animal animal = new Dog();
		animal.setName("Shiro");
		animal.setColor("White");
		animal.setNature("Omnivores");
		System.out.println(animal.toString());
		new Dog().shout();
		Animal animal1 = new Cat();
		animal1.setName("Tom");
		animal1.setColor("Gray");
		animal1.setNature("Carnivores");
		System.out.println(animal1.toString());
		new Cat().shout();
		Animal animal3=new Horse();
		animal3.setName("Siddha");
		animal3.setColor("Brown");
		animal3.setNature("Harbivores");
		System.out.println(animal3.toString());
		new Horse().shout();
	}

}
