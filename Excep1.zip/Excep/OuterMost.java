package Excep;

public class OuterMost {
	void showOuterMost() {
		System.out.println("I am OuterMost...");
	}

	public class Inner {
		void showInner() {
			System.out.println("I am Inner...");
		}

		public class InnerMost {
			void showInnerMost() {
				System.out.println("I am InnerMost...");
				
			}

		}
	}

	public static void main(String[] args) {
		OuterMost om = new OuterMost();
		om.showOuterMost();
		OuterMost.Inner.InnerMost oii = new OuterMost(). new Inner(). new InnerMost();
		OuterMost.Inner oii1 = new OuterMost(). new Inner();
		oii.showInnerMost();
		oii1.showInner();
		

	}

}
