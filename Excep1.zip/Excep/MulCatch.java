package Excep;

import java.io.*;
import java.util.InputMismatchException;
import java.util.Scanner;

public class MulCatch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two Values :");
		try {
			int x[]={4,6,8,7,9};
			System.out.println(x[5]);
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = a / b;
			MulCatch m=null;
			m.toString();
			
		} 
		catch (ArrayIndexOutOfBoundsException aio) 
		{
			System.out.println(aio);
			int a = sc.nextInt();
			int b = sc.nextInt();
			try{
			int c = a / b;
			}
			catch (ArithmeticException ae) 
			{
				System.out.println(ae);
				MulCatch m=null;
				m.toString();
			}
			
		} 
		catch (InputMismatchException ime) 
		{
			System.out.println(ime);
		} 
		catch (NumberFormatException nfe) 
		{
			System.out.println(nfe);
		} 
		
		catch (Exception ae) 
		{
			System.out.println(ae);
		} 
		finally 
		{
			System.out.println("Finally....");
		}

	}

}
