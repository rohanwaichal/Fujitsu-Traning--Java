package Excep;

import java.util.Scanner;

public class DupliChar {

	Scanner sc = new Scanner(System.in);
	void findDupli(String e){
		int count=0;
		System.out.println("Entered String :"+e);
		System.out.println("Enter the charactor to be counted :");
		char w=sc.next().charAt(0);
		for(int i=0;i<e.length();i++){
			if(e.charAt(i)==w){
				count++;
			}
		}
		System.out.println(count);
	}
	void mulDup(String r){
		int []arr=new int[5];
		char [] ch=new char[5];
		for(int i=0;i<r.length();i++){
			ch[i]=r.charAt(i);
			arr[i]=findCount(ch[i]);
		}
		for(int i=0;i<5;i++){
			System.out.println(ch[i]);
			
		}
		for(int i=0;i<5;i++){
		System.out.println(arr[i]);
	}
	}
	int findCount(char e){
		int c=0;
		for(int i=0;i<a.length();i++){
		if(a.charAt(i)==e){
			c++;
		}
		}
		return c;
	}
	static String a;
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a String :");
		a=sc.next();
		DupliChar d = new DupliChar();
		d.mulDup(a);

	}

}
