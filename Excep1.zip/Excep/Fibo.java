package Excep;

public class Fibo {

	public static void main(String[] args) {
		int f1=0,f2=1,f3;
		f3=f1+f2;
		System.out.print(" "+f1+"\t"+f2+"\t"+(f1+f2));
		for(int i=0;i<5;i++){
			f1=f2;
			f2=f3;
			f3=f1+f2;
			System.out.print("\t"+f3);
		}

	}

}
