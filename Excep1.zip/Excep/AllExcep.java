package Excep;

import java.util.Scanner;

public class AllExcep {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two Values :");
		try {
			int a = sc.nextInt();
			int b = sc.nextInt();
			int c = a / b;
		} catch (Exception e) {
			try {
				System.out.println(e);
				System.out.println("Enter two values :");
				int a = sc.nextInt();
				int b = sc.nextInt();
				int c = a / b;
			} catch (Exception e1) {
				System.out.println(e1);
			}
			
		}
	}

}
