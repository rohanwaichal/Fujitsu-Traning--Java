package Project4Ondatabase;

import java.util.List;
import java.util.Scanner;

import exercise3.Employee;

public class ClassController {
	static Student getStudent() {
 Scanner sc = new Scanner(System.in);
		System.out.println("Enter student Id,name,department,mark1,mark2,mark3");
		int id = sc.nextInt();
		String name = sc.next();
		String department = sc.next();
		int m1=sc.nextInt();
		int m2=sc.nextInt();
		int m3=sc.nextInt();
		Student student = new Student(id,name,department,m1,m2,m3);
		return student;
	}

	public static void add(Student student) {
		ClassService.addStudent(student);
	}

	public static void update(int id, String name) {
		ClassService.update(id, name);
		}

	public static List<Student> findAll() {
		return ClassService.findAll();
	}

	public static void delete(int id) {
		System.out.println("class controller");
		ClassService.delete(id);

	}

	public static Student findById(Student student) {
		return ClassService.findById(student);
	}


}
