package Project4Ondatabase;

import java.util.List;
import java.awt.image.RescaleOp;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class ClassDAO {
static	ArrayList<Student> AL = new ArrayList<>();
static Student student=new Student();
	public static List<Student> findAll() {
		Connection con = ClassConnection.getConnection();
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from student;");
			while (rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getInt(4)
						+ " " + rs.getInt(5) + " " + rs.getInt(6));
				Student student = new Student();
				student.setID(rs.getInt(1));
				student.setName(rs.getString(2));
				student.setDepartment(rs.getString(3));
				student.setMark1(rs.getInt(4));
				student.setMark2(rs.getInt(5));
				student.setMark3(rs.getInt(6));
				AL.add(student);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return AL;
	}

	public static Student findByID(Student student) {
		Connection con = ClassConnection.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("select * from student where id=?");
			//student = new Student();
			ps.setInt(1, student.getID());
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getInt(1) + " " + rs.getString(2) + " " + rs.getString(3) + " " + rs.getInt(4)
						+ " " + rs.getInt(5) + " " + rs.getInt(6));
				student.setID(rs.getInt(1));
				student.setName(rs.getString(2));
				student.setDepartment(rs.getString(3));
				student.setMark1(rs.getInt(4));
				student.setMark2(rs.getInt(5));
				student.setMark3(rs.getInt(6));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return student;
	}

	public static void deleteRecord(Student student) {
		Connection con = ClassConnection.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("delete from student where id=?");
			//student = new Student();
			ps.setInt(1, student.getID());
			int rows = ps.executeUpdate();
			System.out.println("Number of rows affected :" + rows);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Student updateRecord(Student student) {
		Connection con = ClassConnection.getConnection();
		PreparedStatement ps;
		try {
			ps = con.prepareStatement("update student set name=? where id=?");
		//	student = new Student();
			
			ps.setString(1, student.getName());
			ps.setInt(2, student.getID());
			int rows = ps.executeUpdate();
			System.out.println("Number of rows affected :" + rows);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return student;
	}
	public static void insertRecord(Student student){
		Connection con = ClassConnection.getConnection();
		PreparedStatement ps;
		try{
			ps=con.prepareStatement("insert into student(id, name, department, mark1, mark2, mark3) values(?,?,?,?,?,?)");
			ps.setInt(1, student.getID());
			ps.setString(2, student.getName());
			ps.setString(3, student.getDepartment());
			ps.setInt(4, student.getMark1());
			ps.setInt(5, student.getMark2());
			ps.setInt(6, student.getMark3());
			int rows=ps.executeUpdate();
			System.out.println("Number of rows affected :" + rows);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void GenerateReport(Student student)
	{
		//Student student1=new Student();
		student=findByID(student);
		System.out.println("-------------------------------------------------------------------");
        System.out.println("                     Report Card                                   ");
		System.out.println("-------------------------------------------------------------------");
		System.out.println("\tStudent ID:"+student.getID());
		System.out.println("\tName of Student:"+student.getName());
		System.out.println("-------------------------------------------------------------------");
		System.out.println("\tMarks1:"+student.getMark1());
		System.out.println("\tMarks1:"+student.getMark2());
		System.out.println("\tMarks1:"+student.getMark3());
		System.out.println("-------------------------------------------------------------------");

	}
}

