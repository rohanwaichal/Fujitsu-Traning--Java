package Project4Ondatabase;

import java.sql.Connection;
import java.sql.DriverManager;

public class ClassConnection {
	public static Connection getConnection() {
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_db", "root",
					"1234");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;
	}

}
