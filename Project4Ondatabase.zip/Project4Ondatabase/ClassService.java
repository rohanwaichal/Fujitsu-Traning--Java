package Project4Ondatabase;

import java.util.Iterator;
import java.util.List;

public class ClassService {
	static Student student = new Student();
	public static List<Student> findAll() {
		return ClassDAO.findAll();
	
	}
	public static void addStudent(Student student)
	{
		try
		{
			if(student.getID()<0)
			{ System.out.println("Negative ID");
			}
			else{
				ClassDAO.insertRecord(student);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public static void update(int id,String name)
	{
		for (Student student :ClassDAO.AL){
			if (student.getID() == id) {
				student.setName(name);
				student = ClassDAO.updateRecord(student);
				System.out.println(student);
				break;
			}

		}
		
	}
	public static void delete(int id) {
	             student.setID(id);
				ClassDAO.deleteRecord(student);
				System.out.println("Class Service");
			
			}
		
	

	public static Student findById(Student s) {
		Student stud = null;
		if (s.getID() == 0) {
			try {
				//throw new InvalidInputException("Id is invalid");
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		} else {
			stud = ClassDAO.findByID(s);
		}
		return stud;
	}
	

}
