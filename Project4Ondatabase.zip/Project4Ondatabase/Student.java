package Project4Ondatabase;

public class Student {
	public static int count=0;
	public Student() {
		super();
		count++;
	}
	public Student(int iD, String name, String department, int mark1, int mark2, int mark3) {
		super();
		ID = iD;
		Name = name;
		this.department = department;
		this.mark1 = mark1;
		this.mark2 = mark2;
		this.mark3 = mark3;
	}
	private int ID;
	private String Name;
	private String department;
	private int mark1;
	private int mark2;
	private int mark3;
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public int getMark1() {
		return mark1;
	}
	public void setMark1(int mark1) {
		this.mark1 = mark1;
	}
	public int getMark2() {
		return mark2;
	}
	public void setMark2(int mark2) {
		this.mark2 = mark2;
	}
	public int getMark3() {
		return mark3;
	}
	public void setMark3(int mark3) {
		this.mark3 = mark3;
	}
	@Override
	public String toString() {
		return "Student [ID=" + ID + ", Name=" + Name + ", department=" + department + ", mark1=" + mark1 + ", mark2="
				+ mark2 + ", mark3=" + mark3 + "]";
	}
	
	

}
