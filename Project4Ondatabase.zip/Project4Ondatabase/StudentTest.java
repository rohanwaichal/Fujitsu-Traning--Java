package Project4Ondatabase;

import java.util.Scanner;

import ProjectOnCollection2.EmployeeInfo;

public class StudentTest {

	static Student student=new Student();
	public static void main(String[] args) {
		int ch;
		do
		{  
			Scanner scanner=new Scanner(System.in);
			System.out.println("***********MENU***********");
			System.out.println(" 1.AddRecord \n 2.DeleteRecord \n 3.FindRecord \n 4.DisplayRecord \n 5.UpdateRecord\n 6.GenerateReoport\n 7.Exit \n Enter your choice:");
			ch=scanner.nextInt();
			switch(ch){
			case 1:
				ClassController.add(ClassController.getStudent());break;
			case 2:ClassController.findAll();
				System.out.println("Enter the id you want to delete :");
				int id=scanner.nextInt();
				ClassController.delete(id);break;
			case 3:System.out.println("Enter the id you want to search :");
				    int ids=scanner.nextInt();
					student.setID(ids);
					Student student1 = ClassController.findById(student);
					System.out.println(student1);
					break;
			case 4:ClassController.findAll();break;
			case 5:System.out.println("Enter the id you want to update :");
				int idu=scanner.nextInt();
				System.out.println("Enter new name :");
				String newName=scanner.next();
				student.setID(idu);
				student.setName(newName);
				ClassController.update(student.getID(),student.getName());break;
			case 6:System.out.println("Enter the id of which u want report :");
		           int idsp=scanner.nextInt();
			       student.setID(idsp);
				ClassDAO.GenerateReport(student);break;
			case 7:break;
			default:System.out.println("Invalid input");
			}
						
		}while(ch!=7);
	
		System.out.println(Student.count);
	}

}
