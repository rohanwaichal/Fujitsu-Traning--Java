select * from students;
insert into students values(2222,'bhagyashri','BAS',56,67,78);