package exercise3;

public class Engineer extends TechnicalStaff {
String engineer;

public Engineer(int id, String name, int salaryPay, String tech, String engineer) {
	super(id, name, salaryPay, tech);
	this.engineer = engineer;
}
public static void main(String[] args) {
	Engineer engineer = new Engineer(001,"Rohan",50000,"Engineer/Developer","Computer..");
	System.out.println(engineer);
}
@Override
public String toString() {
	return "Engineer [engineer=" + engineer + ", tech=" + tech + ", salaryPay=" + salaryPay + "]";
}
}
