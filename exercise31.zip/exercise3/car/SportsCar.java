package exercise3.car;

public class SportsCar extends Car{
	String AirBagType="Yes";

	void display(){
		super.display();
		System.out.println("Is Airbags enable :"+AirBagType);
	}
	public static void main(String[] args) {
		Car car = new SportsCar();
		car.drive(350, 8);
		car.display();
	}

}
