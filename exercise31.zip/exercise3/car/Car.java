package exercise3.car;

public class Car {
	int speed, noOfGear;
	void drive(int a,int b){
		speed=a;
		noOfGear=b;
	}
	void display(){
		System.out.println("Initial Speed :"+speed);
		System.out.println("Number of Gears :"+noOfGear);
	}

}
