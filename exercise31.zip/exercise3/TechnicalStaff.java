package exercise3;

public class TechnicalStaff extends SalariedPay {
	String tech;

	public TechnicalStaff(int id, String name, int salaryPay, String tech) {
		super(id, name, salaryPay);
		this.tech = tech;
	}

}
