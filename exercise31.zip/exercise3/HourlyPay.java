package exercise3;

public class HourlyPay extends Employee {
	
	int hourlyPay;
public HourlyPay(int id, String name,int hourlyPay) {
		super(id, name);
		this.hourlyPay=hourlyPay;
	}



//Employee e = new Employee(1,"diksha");
}
