package exercise3;

public class Executive extends SalariedPay {
String executive;

public Executive(int id, String name, int salaryPay, String executive) {
	super(id, name, salaryPay);
	this.executive = executive;
}

}
