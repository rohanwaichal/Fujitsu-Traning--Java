package exercise3;

public class SalariedPay extends Employee{
     int salaryPay;
	public SalariedPay(int id, String name,int salaryPay) {
		super(id, name);
		this.salaryPay=salaryPay;
		
	}

}
