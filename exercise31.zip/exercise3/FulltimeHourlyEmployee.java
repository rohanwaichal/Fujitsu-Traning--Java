package exercise3;

public class FulltimeHourlyEmployee extends HourlyPay {
	String fulltime;

	public FulltimeHourlyEmployee(int id, String name, int hourlyPay, String fulltime) {
		super(id, name, hourlyPay);
		this.fulltime = fulltime;
	}

	
	
}
