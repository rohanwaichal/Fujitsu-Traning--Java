package exercise3;

public class PartTimeEmployee extends HourlyPay {
	String parttime;

	public PartTimeEmployee(int id, String name, int hourlyPay, String parttime) {
		super(id, name, hourlyPay);
		this.parttime = parttime;
	}

}
