package exercise3;

public class Tchnical extends TechnicalStaff{
	String Techinical;

	public Tchnical(int id, String name, int salaryPay, String tech, String techinical) {
		super(id, name, salaryPay, tech);
		Techinical = techinical;
	}
	

}
