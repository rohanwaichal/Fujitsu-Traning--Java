package Excep;

import java.util.Scanner;

public class UserDefinedException {
	public static void main(String[] args) {
		try{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter the age and Name:");
			String name=sc.next();
			int age=sc.nextInt();
			if(age>=18&&age<60)
			{
		     System.out.println("Age entered is valid");
			}
			else
			{
				throw new AgeInvalidException("Age is invalid");
			}
		}
		catch(Exception e){
			System.out.println(e);
			
		}
		
	}

}
class AgeInvalidException extends Exception
{
  	String msg;

	public AgeInvalidException(String msg) {
		super();
		this.msg = msg;

		System.out.println(msg);
	}
  	
}
