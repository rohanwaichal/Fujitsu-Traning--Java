package Excep;

import java.util.Scanner;

public class DivisionException {
	public static void main(String[] args) {
		DivisionException divisionException = new DivisionException();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the two values:");
		int x = sc.nextInt();
		int y = sc.nextInt();
		int quo = divisionException.divide(x, y);

		try {
			if (y == 0) {
				throw new DivideByException("The Divison can not be done by 0");
			}

		} catch (Exception e) {
		}

	}

	int divide(int x1, int y1) {
		return x1 / y1;

	}

}

class DivideByException extends Exception {
	String msg;

	public DivideByException(String msg) {
		super();
		this.msg = msg;
		System.out.println(msg);
	}
}
