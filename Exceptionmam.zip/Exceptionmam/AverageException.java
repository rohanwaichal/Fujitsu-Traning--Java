package Excep;

import java.util.Scanner;

public class AverageException {
	public static void main(String[] args) {
		int arr[]=new int[5];
		for(int i=0;i<args.length;i++)
		{
		 arr[i]=Integer.parseInt(args[i]);
		}
		try{
		if(args.length<5){
			throw new ArrayIndexOutOfBoundException("Enter exact 5 Elements...");
		}
		else
		{
			int sum=0;
			for(int i=0;i<5;i++)
			{
			sum=sum+arr[i];
		    }
			System.out.println("Average="+sum/5);
			
			
		}
		}
		catch(Exception e){}

  }
}
class ArrayIndexOutOfBoundException extends Exception
{
	String msg;

	public ArrayIndexOutOfBoundException(String msg) {
		super();
		this.msg = msg;
		System.out.println(msg);
	}


}
