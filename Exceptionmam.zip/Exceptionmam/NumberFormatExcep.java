package Excep;

import java.util.Scanner;

public class NumberFormatExcep {
	String name;
	int m1,m2;
	void getData(){
		try{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name :");
		name=sc.nextLine();
		System.out.println("Enter the two subject marks :");
		m1=Integer.parseInt(sc.next());
		m2=Integer.parseInt(sc.next());
		if((m1<0||m1>100)||(m2<0||m2>100)){
			throw new MarksOutOfRangeException("Marks out of Range...");
		}
		}catch(Exception e){
			System.out.println(e);
			System.out.println("Enter again...");
			getData();
		}
	}
	public static void main(String[] args) {
		NumberFormatExcep numberFormatExcep = new NumberFormatExcep();
		try{
			numberFormatExcep.getData();
			}catch(Exception e){
			
		}

	}

}
class MarksOutOfRangeException extends Exception
{
	String msg;

	public MarksOutOfRangeException(String msg) {
		super();
		this.msg = msg;
		System.out.println(msg);
	}
}
