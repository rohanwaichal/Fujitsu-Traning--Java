package Excep;

import java.util.*;

public class MathOperation {

	public static void main(String[] args) {
	int arr[]=new int[5];
	int avg=0;
	try{
	for(int i=0;i<arr.length;i++){
		arr[i]=Integer.parseInt(args[i]);
		avg=avg+arr[i];
	}
	System.out.println("Average :"+(avg/5));
	}catch(ArrayIndexOutOfBoundsException e){System.out.println(e);}
	catch(NumberFormatException e){System.out.println(e);}
	catch(InputMismatchException e){System.out.println(e);}
	catch(Exception e){System.out.println(e);}
	
	

	}

}
