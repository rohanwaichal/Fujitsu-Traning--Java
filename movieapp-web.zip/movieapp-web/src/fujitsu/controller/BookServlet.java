package fujitsu.controller;

import java.io.IOException;

import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.MovieDao;
import Movie.Movie;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		
		
		// 

		// MovieDao.bookTicket(movie);
		List<Movie> booktickets = MovieDao.customerDetails();
		System.out.println(booktickets.size());
		System.out.println(booktickets);
		request.setAttribute("BOOKTICKETS", booktickets);
		RequestDispatcher rd = request.getRequestDispatcher("BookTicket.jsp");
		rd.forward(request, response);

	}

}
