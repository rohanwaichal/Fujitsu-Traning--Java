package fujitsu.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.MovieDao;
import Movie.Movie;

/**
 * Servlet implementation class AddServlet
 */
@WebServlet("/AddServlet")
public class AddServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Data Added Successfully....!").append(request.getContextPath());
		int movie_id = Integer.parseInt(request.getParameter("movie_id"));
		String Customer_name = request.getParameter("Customer_name");
		int no_of_tickets = Integer.parseInt(request.getParameter("no_of_tickets"));

		Service.MovieService service = new Service.MovieService();
		Movie movie = new Movie(movie_id, Customer_name, no_of_tickets);
		
	//	service.addCustomer(movie);
		List<Movie> list = MovieDao.customerDetails();
		request.setAttribute("BOOKTICKETS", list);
		RequestDispatcher rd = request.getRequestDispatcher("BookTicket.jsp");
		rd.forward(request, response);
	}

}
